//
//  ViewController.swift
//  CountryCodeToFalg
//
//  Created by Rajesh Kishanchand on 8/26/19.
//  Copyright © 2019 harish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var country = [String]()
    var countryemoji = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        country = ["IN","SA","PK","SL","BN"]
        
        country.forEach { code in
            
            print(code.isoToEmaojiFlag)
            countryemoji.append(code.isoToEmaojiFlag)
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.countryemoji.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = self.countryemoji[indexPath.row]
        return cell!
    }
    
}




extension String{
    
    var isoToEmaojiFlag :String{
        let code = self.uppercased()
        guard Locale.isoRegionCodes.contains(code) else {
            return ""
        }
        let flag = code
        .unicodeScalars
            .reduce("", { (accumulater, element) -> String in
              
                guard let scalar = UnicodeScalar(127397 + element.value) else {
                  return accumulater
                }
              return accumulater + String(scalar)
        })
        return flag
        }
    
}

